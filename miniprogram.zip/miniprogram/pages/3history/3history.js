const db = wx.cloud.database({ env: 'czj666-5gpdmso73a7452a5' });//初始化数据库
const _ = db.command;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchKey: "",
    history: [],
    arr:[],
    goodList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  
  // 获取输入的搜索
  getSearchKey: function(e) {
    this.setData({
     searchKey: e.detail.value
    })
    wx.setStorage({
      data: this.data.searchKey,
      key: 'nextPage',
    })
  
   },
   
   // 清空page对象data的history数组 重置缓存为[]
   clearHistory: function() {
    this.setData({
     history: []
    })
    wx.setStorageSync("history", [])
   },
   
   //清空搜索栏内容
   clear: function () {
    this.setData({
      searchKey:""
    })
    console.log(1234)
  },
  ToHistorySearchPage:function(event){
    wx: wx.showLoading({
      title: '搜素中',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) {wx.hideLoading()},
    }
    )
    var index = event.currentTarget.dataset.index;
    let arr = wx.getStorageSync('history')
    wx.setStorage({
      data: arr[index],
      key: 'nextPage',
    })
    db.collection('EnglishHeader').where({
      name: db.RegExp({
        regexp: arr[index],//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
      console.log(res.data)
      // --------------------------------------
      let str = JSON.stringify(res.data)
      let temp= res.data
      console.log(123445)
      if(temp.length>0){
      wx.setStorage({
        key:"result",
        data: res.data
      })
      //ssssssssssssss
      wx.redirectTo({
        url: '../4result/4result'
      })
    }
    else{
      wx.showToast({
        title: '结果为空',
        image: '../../images/null.png',
        duration: 1000,
      })
      console.log("我是搜索不到的打印------------------------")
    }
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })

    console.log("搜素结果： ",arr[index])

  },
   
  // input失去焦点函数
   routeToSearchResPage: function(e) {
    //对历史记录的点击事件 已忽略
    let _this = this;
    let _searchKey = this.data.searchKey;
    if (!this.data.searchKey) {
      wx.showToast({
        title: '搜索值不能为空', // 标题
        image: '../../images/警告.png',
        duration: 1500  // 提示窗停留时间，默认1500ms
      })
      return    false;
    }
    let history = wx.getStorageSync("history") || [];
    let arr=history.indexOf(this.data.searchKey);
    if(arr<0){
      history.push(this.data.searchKey)
      wx.setStorageSync("history", history);   //把输入值放入本地内存中
    }
    //-----------------------------查找数据库------------------------------
    wx: wx.showLoading({
      title: '搜素中',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) {wx.hideLoading()},
    }
    )
    //重新给数组赋值为空
    this.setData({
      'goodList': []
    })
    // 数据库正则对象
    db.collection('EnglishHeader').where({
      name: db.RegExp({
        regexp: this.data.searchKey,//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
      console.log(res.data)
      // --------------------------------------
      let str = JSON.stringify(res.data)
      let temp = res.data
      if(temp.length>0){
      wx.setStorage({
        key:"result",
        data: res.data
      })
      //ssssss
      wx.redirectTo({
        url: '../4result/4result'
      })
    }
    else{
      wx.showToast({
        title: '结果为空',
        image: '../../images/null.png',
        duration: 1000

      })
    }
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })
  },

  /**
   * 生命周期函数--监听页面显示，不用任何操作会自己显示出来。
   */
  onShow: function () {
      this.setData({
      history: wx.getStorageSync("history") || []

      })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})




