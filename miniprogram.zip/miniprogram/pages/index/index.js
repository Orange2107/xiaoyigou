// index.js
// 获取应用实例
const db = wx.cloud.database({env:'czj666-5gpdmso73a7452a5'});
const app = getApp()

Page({
  data: {
    searchKey: "",
    list: [
      {
        name: '手机',
        
      },
      {
        name: '电脑',
     
      },
      {
        name: '耳机',
    
      },
      {
        name: '饮料',
       
      },
      {
        name: '化妆品',
    
      },    
      {
        name: '文具',
    
      },   
      {
        name: '衣架',
     
      },   
      {
        name: '毛巾',
  
      }


    ]
  },
  // 页面跳转
  jumppage:function() {

    wx.navigateTo({
      url: '../3history/3history'
    })
  },
  bindGetUserInfo: function(e) {
    if (e.detail.userInfo) {
        //用户按了允许授权按钮
        var that = this;
        // 获取到用户的信息了，打印到控制台上看下
        console.log("用户的信息如下：");
        console.log(e.detail.userInfo);
        //授权成功后,通过改变 isHide 的值，让实现页面显示出来，把授权页面隐藏起来
        that.setData({
            isHide: false
        });
    } else {
        //用户按了拒绝按钮
        wx.showModal({
            title: '警告',
            content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
            showCancel: false,
            confirmText: '返回授权',
            success: function(res) {
                // 用户没有授权成功，不需要改变 isHide 的值
                if (res.confirm) {
                    console.log('用户点击了“返回授权”');
                }
            }
        });
    }
},
  ToHistorySearchPage:function(event){
    wx: wx.showLoading({
      title: '搜素中',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) {wx.hideLoading()},
    }
    )
    wx.setStorage({
      data: event.target.dataset.text,
      key: 'nextPage',
    })
    db.collection('EnglishHeader').where({
      name: db.RegExp({
        regexp:event.target.dataset.text,//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
      console.log(res.data)
      let str = JSON.stringify(res.data)
      let flag=res.data
      wx.setStorage({
        key:"result",
        data: res.data
      })
      wx.navigateTo({
        url: '../4result/4result'
      })
    
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })

    console.log("搜素结果： ",arr[index])

  },
   
})
