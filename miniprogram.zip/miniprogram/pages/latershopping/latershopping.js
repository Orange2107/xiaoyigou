const date = new Date();
const years = [];
const months = [];
const days = [];
const hours = [];
const minutes = [];
const times=[];
let number=[]
//获取年
for (let i = date.getFullYear(); i <= date.getFullYear() + 1; i++) {
  years.push("" + i);
}
//获取月份
for (let i = 1; i <= 12; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  months.push("" + i);
}
//获取日期
for (let i = 1; i <= 31; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  days.push("" + i);
}
//获取小时
for (let i = 0; i < 24; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  hours.push("" + i);
}
//获取分钟
for (let i = 0; i < 60; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  minutes.push("" + i);
}
Page({
  data: {
    userName: '',
    multiArray: [years, months, days, hours, minutes],
    multiIndex: [0, 9, 16, 10, 17],
    choose_year: '',
  },
  //获取用户输入的用户名
  userNameInput:function(e)
  {
    this.setData({
      userName: e.detail.value
    })
  },
  //获取用户输入的密码
  loginBtnClick: function (e) {
    var flag = true
    console.log("号码："+this.data.userName);
    console.log("time:"+this.data.time)
    var mobile = ''
    mobile = this.data.userName
    var phonetel = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/
    var goodss=wx.getStorageSync('goods');  //获取本地内存中goods的值
    console.log('传递过来的商品名称  ：',goodss.id)   //goods就是我们点击的商品，他有数据库对应的所有属性。
    if (mobile == '') {
    wx.showToast({
      title: '手机号不能为空',
      image:'../../images/警告.png',
      duration: 1000
      
    })
    flag = false
    return false
  } 
  else if (mobile.length != 11) {
    wx.showToast({
      title: '手机号有误！',
      image:'../../images/警告.png',
      duration: 1000
    })
    flag = false
    return false;
  }

  var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
  if (!myreg.test(mobile)) {
    wx.showToast({
      title: '手机号有误！',
      image:'../../images/警告.png',
      duration: 1000
    })
    flag = false
    return false;
  }
  
  if(flag){
    const db = wx.cloud.database();
    /**
     * 向集合counters中添加数据
     */
    db.collection("later_shopping_test").add({
        data:{
            photonumber:this.data.userName,
            date:this.data.time,
            good_id:goodss.id
        }
    })
    .then(res=>{
        console.log(res)
    })
    wx.showModal({
      title:'提示',
      content: '降价时商品信息将通过短信进行通知',
      //time=this.data.time,
      success: function (res) {
        if (res.confirm) {
          
          console.log("OK  ") 
         
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    return true;
  }
  
  },

  /**
 * 生命周期函数--监听页面加载
 */
onLoad: function (options) {
  //设置默认的年份
  this.setData({
    choose_year: this.data.multiArray[0][0]
  })
},
//获取时间日期
bindMultiPickerChange: function (e) {
  // console.log('picker发送选择改变，携带值为', e.detail.value)
  this.setData({
    multiIndex: e.detail.value
  })
  const index = this.data.multiIndex;
  const year = this.data.multiArray[0][index[0]];
  const month = this.data.multiArray[1][index[1]];
  const day = this.data.multiArray[2][index[2]];
  const hour = this.data.multiArray[3][index[3]];
  const minute = this.data.multiArray[4][index[4]];
  // console.log(`${year}-${month}-${day}-${hour}-${minute}`);
  this.setData({
    time: year + '-' + month + '-' + day + ' ' + hour + ':' + minute
  })
   //console.log(this.data.time);
},
//监听picker的滚动事件
bindMultiPickerColumnChange: function (e) {
  //获取年份
  if (e.detail.column == 0) {
    let choose_year = this.data.multiArray[e.detail.column][e.detail.value];
    console.log(choose_year);
    this.setData({
      choose_year
    })
  }
  //console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
  if (e.detail.column == 1) {
    let num = parseInt(this.data.multiArray[e.detail.column][e.detail.value]);
    let temp = [];
    if (num == 1 || num == 3 || num == 5 || num == 7 || num == 8 || num == 10 || num == 12) { //判断31天的月份
      for (let i = 1; i <= 31; i++) {
        if (i < 10) {
          i = "0" + i;
        }
        temp.push("" + i);
      }
      this.setData({
        ['multiArray[2]']: temp
      });
    } else if (num == 4 || num == 6 || num == 9 || num == 11) { //判断30天的月份
      for (let i = 1; i <= 30; i++) {
        if (i < 10) {
          i = "0" + i;
        }
        temp.push("" + i);
      }
      this.setData({
        ['multiArray[2]']: temp
      });
    } else if (num == 2) { //判断2月份天数
      let year = parseInt(this.data.choose_year);
      console.log(year);
      if (((year % 400 == 0) || (year % 100 != 0)) && (year % 4 == 0)) {
        for (let i = 1; i <= 29; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      } else {
        for (let i = 1; i <= 28; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      }
    }
    console.log(this.data.multiArray[2]);
  }
  var data = {
    multiArray: this.data.multiArray,
    multiIndex: this.data.multiIndex
  };
  data.multiIndex[e.detail.column] = e.detail.value;
  this.setData(data);
},
onLoad:function(){
  var goodss=wx.getStorageSync('goods');  //获取本地内存中goods的值
  console.log('传递过来的商品名称  ：',goodss.id)   //goods就是我们点击的商品，他有数据库对应的所有属性。
  let that = this
  that.setData({
    goodsid: goodss,
  })
},


})