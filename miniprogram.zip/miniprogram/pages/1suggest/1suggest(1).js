// pages/1suggest/1suggest.js
const db = wx.cloud.database({env:'czj666-5gpdmso73a7452a5'});
let col1H = 0;
let col2H = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    goodList2:[],
    goodList:[],
    goodList1:[],
     // 导航状态12
     navState: 0,
     // 今日推荐
     products: [],
    lHeight:0,
    rHeight:0,
    lList:[],
    rList:[],
     // 收藏夹
     id:'',
     job:[],
     savejob:[],

     dataList:[],

  },
  
   //监听滑块
   bindchange(e) {
    // console.log(e.detail.current)
    let index = e.detail.current;
    this.setData({
      navState:index
    })
  },
  onPullDownRefresh:function() 
  {
      //当逻辑执行完后关闭刷新    
      wx.stopPullDownRefresh();
      
  },
  //点击导航
  navSwitch:function(e) {
    // console.log(e.currentTarget.dataset.index)
    let index = e.currentTarget.dataset.index;
    this.setData({
      navState:index
    })
  },
  jumppage:function() {
    wx.navigateTo({
      url: '../3history/3history'
    })
  },

  imgLoad:function(e){
    var lList = this.data.lList;
    var rList = this.data.rList;
    var lHeight = this.data.lHeight;
    var rHeight = this.data.rHeight;
    if (lHeight == rHeight || rHeight > lHeight){
      lList.push(e.currentTarget.dataset.product);
      lHeight += e.detail.height / e.detail.width;
      this.setData({
        lList,
        lHeight
      })
    }else{
      rList.push(e.currentTarget.dataset.product);
      rHeight += e.detail.height / e.detail.width;
      this.setData({
        rList,
        rHeight
      })
    }
  },

  jumpp:function(event) {
    var index = event.currentTarget.dataset.id;   //获取所点击的商品的索引号，从0开始
    wx.setStorageSync('goods', this.data.goodList1[index].good)//把该索引号指定的对象放到本地内存
    console.log(this.data.goodList1[index].good)
    wx.navigateTo({
      url: '../3goods/3goods'
    })
    log("搜索结果ID ：",this.goodList[index]._id )
  },

  jumppp:function(event) {
    var index = event.currentTarget.dataset.id;   //获取所点击的商品的索引号，从0开始
    wx.setStorageSync('goods', this.data.goodList2[index])//把该索引号指定的对象放到本地内存
    wx.navigateTo({
      url: '../3goods/3goods'
    })
    log("搜索结果ID ：",this.goodList[index]._id )
  },
  onPullDownRefresh: function () {
     var promise1 = new Promise((resolve,reject) => {db.collection('EnglishHeader').limit(10).skip(Math.ceil(Math.random()*2100)).get().then(res=>{
      wx.setStorageSync('goodList', res.data)
      resolve();
    })
  })
    promise1.then(()=>{
      this.data.goodList = []
    let goodjob = wx.getStorageSync('goodList')//获得缓存
    this.data.goodList2 = goodjob
    console.log('-------goodjob-----',goodjob)
    for(let i = 0 ; i < goodjob.length ; i++)
    {
      let good1 = {
        goods_id:goodjob[i].id,
        name:goodjob[i].name,
        pic:goodjob[i].pic,
        goods_xiaoliang:goodjob[i].sales,
        price:goodjob[i].price
      } 
      this.data.goodList.push(good1)
    }
    console.log("goodList：",this.data.goodList)
    this.setData({
      goodList:this.data.goodList
     })})
     this.onLoad(); //重新加载onLoad()
  },

  getTuijian: function(){
    var promise1 = new Promise((resolve,reject) => {db.collection('EnglishHeader').limit(10).skip(Math.ceil(Math.random()*156)).get().then(res=>{
      wx.setStorageSync('goodList2', res.data)
      console.log('-------res-----',res.data)
      resolve();
    })
  })
    promise1.then(()=>{
      this.data.goodList = []
    let goodjob = wx.getStorageSync('goodList2')//获得缓存
    this.data.goodList2 = goodjob
    console.log('-------goodjob-----',goodjob)
    for(let i = 0 ; i < goodjob.length ; i++)
    {
      let good1 = {
        goods_id:goodjob[i].id,
        name:goodjob[i].name,
        pic:goodjob[i].pic,
        goods_xiaoliang:goodjob[i].sales,
        price:goodjob[i].price
      } 
      this.data.goodList.push(good1)
    }
    console.log("goodList：",this.data.goodList)
    this.setData({
      goodList:this.data.goodList
     })})
  },

  onLoad:function(options){
    var promise = new Promise((resolve,reject) => {this.getTuijian()
      resolve();
    })
    
    wx.stopPullDownRefresh() //刷新完成后停止下拉刷新动效
    
  },
  onShow: function (options) {
    var promise = new Promise((resolve,reject) => {
      resolve();
    })
    promise.then(()=>{
    console.log(wx.getStorageSync('jobData'));
    let savejob = wx.getStorageSync('jobData')//获得缓存
    this.data.goodList1 = wx.getStorageSync('jobData')
    this.data.dataList = []
    for(let i = 0 ; i < savejob.length ; i++)
    {
      let good = {
        goods_id:savejob[i].good.id,
        goods_title:savejob[i].good.name,
        goods_img:savejob[i].good.pic,
        goods_xiaoliang:savejob[i].good.sales,
        goods_price:savejob[i].good.price
      } 
      this.data.dataList.push(good)
    }
    console.log("-----------收藏列表-----------：",this.data.dataList)
    this.setData({
      dataList:this.data.dataList,
     })
    }
    )
    },

})