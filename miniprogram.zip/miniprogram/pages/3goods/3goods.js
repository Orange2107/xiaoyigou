const app = getApp();
const db = wx.cloud.database({ env: 'czj666-5gpdmso73a7452a5' });//初始化数据库
const _ = db.command;
import * as echarts from '../../ec-canvas/echarts';
var  fzu=new Array();
var temp=new Object();
var time=new Array();
var money=new Array();
function getshuju(canvas,chart,option){
  const dbb= wx.cloud.database({ env: 'czj666-5gpdmso73a7452a5' });//初始化数据库
  dbb.collection('history_price').orderBy('date','desc').where({
    id: _.eq(fzu.id)
  })
    .get({
      success(res) {
        console.log("-------------------商品的名字",res.data.price)
        temp=res.data
        console.log("-------------------temp",temp)
       let reverse=temp.length-1
       for(let i=0;i<temp.length;i++){
            
            money[i]=temp[reverse].price;
            time[i]=temp[reverse].date;
            reverse--;
        
       } 
      wx.setStorage({
        key:"timee",
        data: time
      })    
      wx.setStorage({
        key:"moneyy",
        data: money
      })
        option.xAxis.data = time;
        option.series[0].data = money;
        canvas.setChart(chart);
        chart.setOption(option);
        
       console.log("1")
       console.log("-------------------我是钱在搜索历史价格中",money)
       console.log("-------------------我是时间在搜索历史价格中",time)
      },
      fail(res){
        console.log("-------------------数据查找失败")
        time=" ";
        money=" ";
      }
    })
  }
  
  
  
function initChart(canvas, width, height, dpr) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height,
    devicePixelRatio: dpr // new
  });
  // canvas.setChart(chart);

  var option = {
    title: {
  
      left: 'center'
    },
    color: ["#37A2DA", "#67E0E3", "#9FE6B8"],

    grid: {
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis', 
      position: function (point, params, dom, rect, size) {
        // 鼠标坐标和提示框位置的参考坐标系是：以外层div的左上角那一点为原点，x轴向右，y轴向下
        // 提示框位置
        var x = 0; // x坐标位置
        var y = 0; // y坐标位置
       
        // 当前鼠标位置
        var pointX = point[0];
        var pointY = point[1];
       
        // 提示框大小
        var boxWidth = size.contentSize[0];
        var boxHeight = size.contentSize[1];
       
        // boxWidth > pointX 说明鼠标左边放不下提示框
        if (boxWidth > pointX) {
          x = 5;
        } else { // 左边放的下
          x = pointX - boxWidth;
        }
       
        // boxHeight > pointY 说明鼠标上边放不下提示框
        if (boxHeight > pointY) {
          y = 5;
        } else { // 上边放得下
          y = pointY - boxHeight;
        }
       
        return [x, y];
      },
      formatter:function(params){
       
        return "价格 :"+params[0].data+"\n时间 :"+ params[0].name;
      }
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data:time ,
      // show: false
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
      // show: false
    },
    series: [{
      name: '历史价格',
      type: 'line',
      smooth: true,
      data: [1,2,3,4],
    }, ]

  };
  let mm = wx.getStorageSync('moneyy')
  let tt = wx.getStorageSync('timee')
  console.log("2")
  console.log("-------------------我是钱   在创建图表中",mm)
  console.log("-------------------我是时间  在创建图表中",tt)
  getshuju(canvas,chart,option);
  option.xAxis.data = tt;
  option.series[0].data = mm;
  canvas.setChart(chart);
  wx.removeStorage({
    key: 'moneyy',
  })
  wx.removeStorage({
    key: 'timeee',
  })
  chart.setOption(option);
  return chart;

}
Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  
    data: {
    goods: "",
    goodss:"",
    goodsss:"",
    isLike: true,
    ec: {
      lazyload:true,
      onInit: initChart
    },
    // banner
    imgUrls: [
      "../../images/1.jpg",
      "../../images/2.jpg",
      "../../images/3.jpg",
      
    ]
  },
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动切换
    interval: 3000, //自动切换时间间隔,3s
    duration: 1000, //  滑动动画时长1s
    //收藏
    job: [],
    jobList: [],
    id: '',
    isClick: false,
    jobStorage: [],
    jobId: '',
    //好评率
    probability:"20%",
  //复制链接
  immeBuy:function(e) {
    var that = this;
    let jobData = wx.getStorageSync('goods')
      wx.setClipboardData({
        data:jobData.url,
        success: function (res) {
        }
      })
  },
  //收藏
  haveSave(e) {
    if (!this.data.isClick == true) {
     this.data.isClick = true
     console.log(wx.getStorageSync('jobData'))
     let jobData = wx.getStorageSync('jobData') || []
     console.log(jobData)
     jobData.push({
     jobid: jobData.length,
     id: this.data.goodss.id,
     good:this.data.goodss,
     isClick:this.data.isClick
     })
     console.log('我是收藏------',jobData)
     wx.setStorageSync('jobData', jobData);//设置缓存
     wx.showToast({
     title: '已收藏',
     image:'../../images/收藏.png',
     duration: 1000
     });
    } else {
     this.data.isClick = false
     let jobData = wx.getStorageSync('jobData')
     for(let i = 0 ; i < jobData.length ; i++)
     {
       if(this.data.goodss.id == jobData[i].id)
       {
         jobData.splice(i,1)
         break
       }
     }
     wx.setStorageSync('jobData', jobData)
     wx.showToast({
     title: '已取消收藏',
     image:'../../images/取消收藏.png',
     duration:1000
     });
    }
    this.setData({
     isClick: this.data.isClick
    })
  },
   // 跳到延迟界面
  todelay() {
      wx.navigateTo({
        url: "/pages/latershopping/latershopping",
    })
  },
  onready:function(){
   
  },

  onLoad:function(){
    
    let Data = wx.getStorageSync('jobData') || []
    this.data.goodss=wx.getStorageSync('goods');  //获取本地内存中goods的值
    fzu=wx.getStorageSync('goods');
    console.log("------------我是商品名称------------------",fzu.name)
  //
    console.log('传递过来的商品名称  ：',this.data.goodss.id)   //goods就是我们点击的商品，他有数据库对应的所有属性。
    for(let i = 0 ; i < Data.length ; i++)
    {
      if (Data[i].id == this.data.goodss.id)
      {
        this.data.isClick = Data[i].isClick
      }
    }
    let that = this
    that.setData({
      isClick: this.data.isClick,
      goods: this.data.goodss,
    })
  },

})