// pages/4result/4result.js
var temp="";
const db = wx.cloud.database({env:'czj666-5gpdmso73a7452a5'});//初始化数据库
const productCollection = db.collection('EnglishHeader')
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    searchVal: "",
    topNum: 0,
    //搜索过后商品列表
    goodList:[],
    pagee:0,
    jumpkey: "",
    flag:""
    
  },
//页面跳转
jumpp:function(event) {
  var index = event.currentTarget.dataset.id;   //获取所点击的商品的索引号，从0开始
  wx.setStorageSync('goods', this.data.goodList[index])//把该索引号指定的对象放到本地内存
  wx.navigateTo({
    url: '../3goods/3goods'
  })
  log("搜索结果ID ：",this.goodList[index]._id )
},
jumppage:function() {
  wx.redirectTo({
    url: '../3history/3history'
  })
},
//回到页首
returnTop:function(){
  this.setData({
    scrollHeight:0
   });
},

goTop: function (e) {  // 一键回到顶部
  this.setData({
    topNum: this.data.topNum = 0
  });
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(6591)
    
      let searchshow = wx.getStorageSync('result')
      this.setData({
        searchVal: searchshow,
        goodList:searchshow,
        flag:1
      
    })
   // let searchshow = wx.getStorageSync('result')
    this.setData({
       jumpkey:wx.getStorageSync('nextPage')
    })
    console.log("搜素结果： ",searchshow)
    let that = this
   // that.setData({
    //  searchVal: searchshow,
    //  goodList:searchshow
   // })
    console.log("搜素结果： ",this.goodList)
   for (var i = 0; i < searchVal.length; i++) {
        var title = "goodList[" + i + "].rate"
        var id = "goodList[" + i + "]._id"
        var image = "goodList[" + i + "].pic"
        var rmb = "goodList[" + i + "].price"
        var content = "goodList["+ i +"].name"
        this.setData({
          [title]: searchVal[i].rate,
          [id]:searchVal[i]._id,
          [image]: searchVal[i].pic,
          [rmb]: searchVal[i].price,
          [content]: searchVal[i].name,
        })
  
        console.log(哈哈哈哈哈哈)
        wx.hideLoading();
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function (options) {


  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  loadMore: function(){
     // 数据库正则对象
     let pagee=this.data.pagee+20;
     let val=wx.getStorageSync('nextPage')
     console.log("我是测试为什么多了手机？",val)

     productCollection.skip(pagee).where({
      name: db.RegExp({
        regexp: val,//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
  
      let new_data=res.data
      let old_data=this.data.goodList
      let convey=old_data.concat(new_data)
      console.log("sssssssssss",convey )
      this.setData({
        pagee:pagee,
        goodList:convey
      })
      console.log("我是第二次~~~~~~~~~",res.data)
      console.log(123445)
      
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })
  },
  
})
