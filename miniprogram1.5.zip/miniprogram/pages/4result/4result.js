// pages/4result/4result.js
var temp="";
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    searchVal: "",
    //搜索过后商品列表
    goodList:[]
  },
//页面跳转
jumpp:function() {
  wx.navigateTo({
    url: '../3goods/3goods'
  })
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(6591)
    let searchshow = wx.getStorageSync('result')
    console.log("搜素结果： ",searchshow)
    let that = this
    that.setData({
      searchVal: searchshow,
      goodList:searchshow
    })
    console.log("搜素结果： ",this.goodList)
   for (var i = 0; i < searchVal.length; i++) {
        var title = "goodList[" + i + "].rate"
        var id = "goodList[" + i + "]._id"
        var image = "goodList[" + i + "].pic"
        var rmb = "goodList[" + i + "].price"
        var content = "goodList["+ i +"].name"
        this.setData({
          [title]: searchVal[i].rate,
          [id]:searchVal[i]._id,
          [image]: searchVal[i].pic,
          [rmb]: searchVal[i].price,
          [content]: searchVal[i].name,
        })
  
        console.log(哈哈哈哈哈哈)
        wx.hideLoading();
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function (options) {


  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})