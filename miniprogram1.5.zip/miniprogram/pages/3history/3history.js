// pages/5result/5result.js
const db = wx.cloud.database({env:'czj666-5gpdmso73a7452a5'});//初始化数据库
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchKey: "",
    history: [],
    goodList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  
  // 获取输入的搜索
  getSearchKey: function(e) {
    this.setData({
     searchKey: e.detail.value
    })
   },
   
   // 清空page对象data的history数组 重置缓存为[]
   clearHistory: function() {
    this.setData({
     history: []
    })
    wx.setStorageSync("history", [])
   },
   
   //清空搜索栏内容
   clear: function () {
    this.setData({
      searchKey:""
    })
    console.log(1234)
  },
   
  // input失去焦点函数
   routeToSearchResPage: function(e) {
    //对历史记录的点击事件 已忽略
    let _this = this;
    let _searchKey = this.data.searchKey;
    if (!this.data.searchKey) {
     return
    }
    let history = wx.getStorageSync("history") || [];
    history.push(this.data.searchKey)
    wx.setStorageSync("history", history);   //把输入值放入本地内存中
    //  传参到下一个页面并进行跳转
    //  wx.navigateTo({
    //   url: '../4result/4result',

    // })

    //-----------------------------查找数据库------------------------------
    wx: wx.showLoading({
      title: 'wsile',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) {wx.hideLoading()},
    }
    )
    //重新给数组赋值为空
    this.setData({
      'goodList': []
    })
    // 数据库正则对象
    db.collection('EnglishHeader').where({
      name: db.RegExp({
        regexp: this.data.searchKey,//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
      console.log(res.data)
      // --------------------------------------
      let str = JSON.stringify(res.data)
      console.log(123445)
      wx.setStorage({
        key:"result",
        data: res.data
      })
      wx.navigateTo({
        url: '../4result/4result'
      })
      
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })
  },

  /**
   * 生命周期函数--监听页面显示，不用任何操作会自己显示出来。
   */
  onShow: function () {
      this.setData({
      history: wx.getStorageSync("history") || []
     })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})




