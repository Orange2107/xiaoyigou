// pages/search/search.js
const db = wx.cloud.database({env:'czj666-5gpdmso73a7452a5'});//初始化数据库
Page({

  /**
   * 页面的初始数据
   */
  data: {
    searchVal: "",
    //搜索过后商品列表
    goodList:[]
  },
  input(e) {
    this.setData({
      searchVal: e.detail.value    //Input的输入
    })
    console.log(e.detail.value)
  },
  // clear: function () {
  //   this.setData({
  //     searchVal: ""
  //   })
  // },
  //商品关键字模糊搜索
  search: function () {
    wx: wx.showLoading({
      title: 'wsile',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) {wx.hideLoading()},
    }
    )
    //重新给数组赋值为空
    this.setData({
      'goodList': []
    })
    // 数据库正则对象
    db.collection('EnglishHeader').where({
      name: db.RegExp({
        regexp: this.data.searchVal,//做为关键字进行匹配
        options: 'i',//不区分大小写
      })
    })
    .get().then(res => {
      console.log(res.data)
      // --------------------------------------
      let str = JSON.stringify(res.data);
      
      wx.navigateTo({
        url: '../4result/4result?data=' + str
      })
      // ------------------------------------------
      // for (var i = 0; i < res.data.length; i++) {
      //   var title = "goodList[" + i + "].rate"
      //   var id = "goodList[" + i + "]._id"
      //   var image = "goodList[" + i + "].pic"
      //   var rmb = "goodList[" + i + "].price"
      //   var content = "goodList["+ i +"].name"
      //   this.setData({
      //     [title]: res.data[i].rate,
      //     [id]: res.data[i]._id,
      //     [image]: res.data[i].pic,
      //     [rmb]: res.data[i].price,
      //     [content]: res.data[i].name,
      //   })
      //   console.log(this.data.goodList[i].content)
      //   wx.hideLoading();
      // }
    }).catch(err => {
      console.error(err)
      wx.hideLoading();
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log(options.searchVal)//输出其他页面传来的值
    if (options.searchVal != '') {
      console.log("不为空")
      this.setData({
        searchVal: options.searchVal
      })
      this.search();
    }else{
      console.log("为空")
      that.search();
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
})
